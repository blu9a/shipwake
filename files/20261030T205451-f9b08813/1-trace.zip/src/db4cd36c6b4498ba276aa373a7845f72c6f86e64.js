// Generated from: ../features/recordings.feature
import { test } from "../acceptance/project.mjs";

test.describe('Watching what a scenario did', () => {

  test('A recording starts where the page shows something', async ({ Given, When, Then, browser, page, repo, served, world }) => { 
    await Given('a scenario recorded while its page was still blank for the first second', null, { browser, repo }); 
    await When('I open the scenario\'s recording', null, { page, served, world }); 
    await Then('it shows the page from the start, not a blank screen', null, { world }); 
  });

  test('A blank moment holds the last picture', async ({ Given, When, Then, browser, page, repo, served, world }) => { 
    await Given('a scenario recorded while its page went blank for a second in the middle', null, { browser, repo }); 
    await When('I play the recording through that second', null, { page, served, world }); 
    await Then('the page\'s last picture stays on screen until the page is back', null, { world }); 
  });

  test('A feature\'s video ends each scenario on its result', async ({ Given, When, Then, browser, page, repo, served, world }) => { 
    await Given('a feature with two recorded scenarios', null, { browser, repo }); 
    await When('I watch the feature', null, { page, served, world }); 
    await Then('the end of the first scenario stays on screen a moment before the second begins', null, { world }); 
  });

});

// == technical section ==

test.use({
  $test: [({}, use) => use(test), { scope: 'test', box: true }],
  $uri: [({}, use) => use('../features/recordings.feature'), { scope: 'test', box: true }],
  $bddFileData: [({}, use) => use(bddFileData), { scope: "test", box: true }],
});

const bddFileData = [ // bdd-data-start
  {"pwTestLine":6,"pickleLine":4,"tags":[],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given a scenario recorded while its page was still blank for the first second","stepMatchArguments":[]},{"pwStepLine":8,"gherkinStepLine":6,"keywordType":"Action","textWithKeyword":"When I open the scenario's recording","stepMatchArguments":[]},{"pwStepLine":9,"gherkinStepLine":7,"keywordType":"Outcome","textWithKeyword":"Then it shows the page from the start, not a blank screen","stepMatchArguments":[]}]},
  {"pwTestLine":12,"pickleLine":9,"tags":[],"steps":[{"pwStepLine":13,"gherkinStepLine":10,"keywordType":"Context","textWithKeyword":"Given a scenario recorded while its page went blank for a second in the middle","stepMatchArguments":[]},{"pwStepLine":14,"gherkinStepLine":11,"keywordType":"Action","textWithKeyword":"When I play the recording through that second","stepMatchArguments":[]},{"pwStepLine":15,"gherkinStepLine":12,"keywordType":"Outcome","textWithKeyword":"Then the page's last picture stays on screen until the page is back","stepMatchArguments":[]}]},
  {"pwTestLine":18,"pickleLine":14,"tags":[],"steps":[{"pwStepLine":19,"gherkinStepLine":15,"keywordType":"Context","textWithKeyword":"Given a feature with two recorded scenarios","stepMatchArguments":[]},{"pwStepLine":20,"gherkinStepLine":16,"keywordType":"Action","textWithKeyword":"When I watch the feature","stepMatchArguments":[]},{"pwStepLine":21,"gherkinStepLine":17,"keywordType":"Outcome","textWithKeyword":"Then the end of the first scenario stays on screen a moment before the second begins","stepMatchArguments":[]}]},
]; // bdd-data-end